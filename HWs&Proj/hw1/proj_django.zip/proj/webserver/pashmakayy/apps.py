from django.apps import AppConfig


class PashmakayyConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'pashmakayy'
