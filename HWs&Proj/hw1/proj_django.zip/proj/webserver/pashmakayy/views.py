import json
from django.http import HttpResponse
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from .models import Text
# Create your views here.
def get_text(request):
    with open('webserver/statics/script.sh', 'r') as file:
        text = file.read()
    return HttpResponse(text, content_type='text/plain')

@csrf_exempt
def post_text(request):
    if request.method == "POST":
        data = json.loads(request.body , strict=False)
        Text.objects.create(text=data['data'])
    
    return HttpResponse('tamoom da')