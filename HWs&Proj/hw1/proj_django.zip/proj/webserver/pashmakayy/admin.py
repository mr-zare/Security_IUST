from django.contrib import admin
from .models import Text
from django.db import models

admin.site.register(Text)